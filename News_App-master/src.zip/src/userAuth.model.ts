export class UserAuth
{
emailId='';
userPassword=''

}
