export class User{

    emailId = '';
	userName = '';
	userPassword='';
	confirmPassword='';
	securityQuestion='';
	securityAnswer='';
	userAddress='';
    userContactNumber='';
	userGender ='';
	pic='';


}